var express=require('express');
const { destination, deleteDestination, updateDestination, getDestination } = require('../controller/destinationController');
var router=express.Router('');

router.post('/destination',destination);
router.post('/getdestination',getDestination);
router.post('/updatedestination',updateDestination);
router.post('/deletedestination',deleteDestination);


module.exports=router;