var express=require("express");
const { serviceCard, getServiceCard, updateServiceCard, deleteServiceCard } = require("../controller/serviceController");
var router=express.Router("")


router.post("/service",serviceCard);
router.post('/getservice',getServiceCard);
router.post('/updateservice',updateServiceCard);
router.post('/deleteservice',deleteServiceCard);

module.exports=router;