var express=require('express');
var router=express.Router('');
var {package, getPackage, updatePackage, deletePackage}=require('../controller/packageController');



router.post('/package',package);
router.post('/getpackage',getPackage);
router.post('/updatepackage',updatePackage);
router.post('/deletepackage',deletePackage);

module.exports=router;