var express=require("express");
var router=express.Router('');
var {poster,getposter,updateposter,deleteposter}=require('../controller/bannerController');

router.post('/banner',poster);
router.post('/getbanner',getposter);
router.post('/updatebanner',updateposter);
router.post('/deletebanner',deleteposter);

module.exports=router;
