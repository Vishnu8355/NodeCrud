var packageModel=require('../model/packageModel');

exports.package=(req,res)=>{

    var{packageDescription,packageImage,packageRating,packageDay,location,price,packagePerson}=req.body;

    var packageObj=packageModel({
        packageDescription,packageImage,packageRating,packageDay,location,price,packagePerson
    });

    packageObj.save().then((data)=>{
       if(data){return res.status(200).json(data)} 
    }).catch((err)=>{
        if(err){return res.status(400).json(err)}
    });
}


//getDestination..... 

exports.getPackage=(req,res)=>{
    packageModel.find({}).then((data)=>{
        if(data){return res.status(200).json(data)}
    }).catch((err)=>{
        if(err){return res.status(400).json(err)}
    })
}
//updateDestination..... 

exports.updatePackage=(req,res)=>{

    var { _id,  packageDescription,packageImage,packageRating,packageDay,location,price,packagePerson} = req.body;
    packageModel.findOneAndUpdate({ _id: _id }, { $set: {  packageDescription:packageDescription,
        packageImage:packageImage,
        packageRating:packageRating,
        packageDay:packageDay,
        location:location,
        price:price,
        packagePerson:packagePerson} }, { new: true }).then((data) => {
        if (data) { return res.status(200).json(data) }
    }).catch((err) => {
        if (err) { return res.satus(400).json(err) }
    })
}


//delete.......
exports.deletePackage=(req,res)=>{
    const {_id:_id}=req.body;
    packageModel.deleteOne({_id:_id}).then((data)=>{
        if(data){return res.status(200).json(data)}
    }).catch((err)=>{
        if(err){return res.satus(400).json(err)}
    })
}