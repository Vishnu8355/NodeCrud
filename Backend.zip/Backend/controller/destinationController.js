var destinationModel=require('../model/destinationModel');

exports.destination=(req,res)=>{
    var {image,location,offer}=req.body;

    var destinationObj=destinationModel({
        image,location,offer
    });


    destinationObj.save().then((data)=>{
        if(data){return res.status(200).json(data)}
    }).catch((err)=>{
        if(err){return res.status(400).json(err)}
    })


}


//getDestination..... 

exports.getDestination=(req,res)=>{
    destinationModel.find({}).then((data)=>{
        if(data){return res.status(200).json(data)}
    }).catch((err)=>{
        if(err){return res.status(400).json(err)}
    })
}
//updateDestination..... 

exports.updateDestination=(req,res)=>{

    var { _id, image,location,offer } = req.body;
    destinationModel.findOneAndUpdate({ _id: _id }, { $set: { image:image,location:location,offer:offer } }, { new: true }).then((data) => {
        if (data) { return res.status(200).json(data) }
    }).catch((err) => {
        if (err) { return res.satus(400).json(err) }
    })
}


//delete.......
exports.deleteDestination=(req,res)=>{
    const {_id:_id}=req.body;
    destinationModel.deleteOne({_id:_id}).then((data)=>{
        if(data){return res.status(200).json(data)}
    }).catch((err)=>{
        if(err){return res.satus(400).json(err)}
    })
}