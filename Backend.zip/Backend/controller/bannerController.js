var bannerModel = require('../model/bannerModel');

exports.poster = (req, res) => {

    var { heading, paragraph, image } = req.body;

    var posterObj = bannerModel({
        heading, paragraph, image
    });

    posterObj.save().then((data) => {
        if (data) { return res.status(200).json(data) }
    }).catch((err) => {
        if (err) { return res.status(400).json(err) }
    });

}

//get banner......
exports.getposter = (req, res) => {

    bannerModel.find({}).then((data) => {
        if (data) { return res.status(200).json(data) }
    }).catch((err) => {
        if (err) { return res.status(400).json(err) }
    });

}

//update banner....
exports.updateposter = (req, res) => {

    const { _id, heading, paragraph, image } = req.body;

    bannerModel.findOneAndUpdate({ _id: _id }, { $set: { heading: heading, paragraph: paragraph, image: image } }, { new: true }).then((data) => {
        if (data) { return res.status(200).json(data) }
    }).catch((err) => {
        if (err) { return res.status(400).json(err) }
    })
}

//delete banner.....
exports.deleteposter=(req,res)=>{
    const {_id}=req.body;
    bannerModel.deleteOne({_id:_id}).then((data)=>{
        if(data){return res.status(200).json(data)}
    }).catch((err)=>{
        if(err){ return res.status(200).json(err)}
    })
}