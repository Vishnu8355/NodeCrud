var serviceModel = require('../model/serviceModel');
//post service card....
exports.serviceCard = (req, res) => {
    var { serviceType, serviceDescription, logo } = req.body

    var serviceObj = serviceModel({
        serviceType, serviceDescription, logo
    });
    serviceObj.save().then((data) => {
        if (data) { return res.status(200).json(data) }
    }).catch((err) => {
        if (err) { return res.status(400).json(err) }
    });
}

//get service card.....
exports.getServiceCard = (req, res) => {
    serviceModel.find({}).then((data) => {
        if (data) { return res.status(200).json(data) }

    }).catch((err) => {
        if (err) { return res.satus(200).json(err) }
    });
}

//update service card....


exports.updateServiceCard = (req, res) => {
    var { _id, serviceType, serviceDescription, logo } = req.body;
    serviceModel.findOneAndUpdate({ _id: _id }, { $set: { serviceType: serviceType, serviceDescription: serviceDescription, logo: logo } }, { new: true }).then((data) => {
        if (data) { return res.status(200).json(data) }
    }).catch((err) => {
        if (err) { return res.satus(400).json(err) }
    })
}

//delete service card....

exports.deleteServiceCard=(req,res)=>{
    const {_id:_id}=req.body;
    serviceModel.deleteOne({_id:_id}).then((data)=>{
        if(data){return res.status(200).json(data)}
    }).catch((err)=>{
        if(err){return res.satus(400).json(err)}
    })
}