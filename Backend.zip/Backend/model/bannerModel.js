var mongoose=require('mongoose');

const bannerSchema = new mongoose.Schema({
   heading:{
    type:String,
    trim:true
   },
   paragraph:{
    type:String,
    trim:true
   },
   image:{
    type:Array
   }
  });

  module.exports = mongoose.model('banner', bannerSchema);