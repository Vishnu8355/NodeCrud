var mongoose = require('mongoose');

var destinationSchema = new mongoose.Schema({
    image: {
        type: String
    },
    location: {
        type: String
    },
    offer: {
        type: String
    }

})
module.exports = mongoose.model('destination', destinationSchema);