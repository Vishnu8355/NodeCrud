var mongoose=require('mongoose');
var packageSchema=new mongoose.Schema({

  
    packageDescription:{
        type:String,
        trim:true
    },
    packageImage:{
        type:String
    },
    packageRating:{
        type:String
    },
    packageDay:{
        type:Number
    },
    location:{
        type:String
    },
    price:{
        type:Number
    },
    packagePerson:{
        type:String
    }
     
})

module.exports=mongoose.model('packages',packageSchema);