var mongoose=require('mongoose');

var serviceSchema=new mongoose.Schema({

    serviceType:{
        type:String,
        trim:true
    },
    serviceDescription:{
        type:String,
        trim:true
    },
    logo:{
        type:String

    }

})
module.exports=mongoose.model('service',serviceSchema);